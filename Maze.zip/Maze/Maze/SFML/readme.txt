SFML 2.5.0

Note: I have removed a lot of unused files including sound and network support to reduce the download size but if you want those back you can get the full library from https://www.sfml-dev.org/download/sfml/2.5.0/

Keith